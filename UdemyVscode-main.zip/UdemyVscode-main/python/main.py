from lib import my_func3


def main():
    my_func3()


if __name__ == "__main__":
    main()

import sys

argc = len(sys.argv)
argv = sys.argv

print(f"argc: {argc}")
print(f"argv: {argv}")

print(f"Your age is {argv[1]}")

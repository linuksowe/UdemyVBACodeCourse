# VSCode Intro

This is the code for my Udemy course:
*VSCode Intro* by Jan Schaffranek.

## Discount code

Below I have provided a link to the current discount code. You can also send the code to your friends so that they can buy one of my courses.  
With a purchase via my discount codes I receive 95% of the revenue and so you can support me better.

Link to my German courses: [Link](https://github.com/franneck94/YoutubeVideos/blob/main/README.md)

Link to my English courses: [Link](https://github.com/franneck94/YoutubeVideos/blob/main/EnglishCourses.md)

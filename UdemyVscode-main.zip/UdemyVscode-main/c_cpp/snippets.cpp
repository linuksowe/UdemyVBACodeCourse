#include <iostream>

using namespace std;

int main()
{
    vector<int> v;
    v.push_pack(1);

    cout << "hello";
    return 0;
}

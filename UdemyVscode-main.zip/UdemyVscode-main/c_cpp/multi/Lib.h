#ifndef LIB_H
#define LIB_H

int getNumberFromUser();

int min(int a, int b);

int max(int a, int b);

float mean(int a, int b);

#endif
